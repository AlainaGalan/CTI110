def days_in_feb(user_year): #defining a function that will later take the user_year input then return 29 or 28 depending on the input
    if user_year % 4 == 0 and user_year % 100 != 0 or user_year % 400 == 0:
        return 29
    else:
        return 28

if __name__ == '__main__':
    user_year = int(input()) #user input
    print(f'{user_year} has {days_in_feb(user_year)} days in February.') #will print out your output and calls the function, it will return 29 or 28